//from http://perle-development.com/tutorials/andengine-tutorial-01-creating-a-scene/ ||| build simple android application
//1 START
package com.example.spacechase;

import java.util.ArrayList;

import org.andengine.engine.Engine;
import org.andengine.engine.camera.Camera;
import org.andengine.engine.options.EngineOptions;
import org.andengine.engine.options.ScreenOrientation;
import org.andengine.engine.options.resolutionpolicy.RatioResolutionPolicy;
import org.andengine.entity.scene.Scene;
import org.andengine.entity.scene.background.AutoParallaxBackground;
import org.andengine.entity.scene.background.Background;
import org.andengine.entity.scene.background.ParallaxBackground.ParallaxEntity;
import org.andengine.entity.scene.background.RepeatingSpriteBackground;
import org.andengine.entity.scene.background.SpriteBackground;
import org.andengine.entity.sprite.AnimatedSprite;
import org.andengine.entity.sprite.Sprite;
import org.andengine.entity.util.FPSLogger;
import org.andengine.opengl.texture.TextureOptions;
import org.andengine.opengl.texture.atlas.bitmap.BitmapTextureAtlas;
import org.andengine.opengl.texture.atlas.bitmap.BitmapTextureAtlasTextureRegionFactory;
import org.andengine.opengl.texture.atlas.bitmap.source.IBitmapTextureAtlasSource;
import org.andengine.opengl.texture.region.TextureRegion;
import org.andengine.opengl.texture.region.TiledTextureRegion;
import org.andengine.ui.activity.SimpleBaseGameActivity;
import android.content.Context;

import android.util.Log;
import android.view.Display;
 
public class MainActivity extends SimpleBaseGameActivity {
    // ===========================================================
    // Constants
    // ===========================================================
    static int CAMERA_WIDTH = 1280;
    static int CAMERA_HEIGHT = 720;//To do reverse it
    //a variable that should scale the screen on different devices. it can do that be either looking at different screen sizes and scaling the place of objects or by using some AntEngine method
    public double ScreenScalerX = 0.0;
    public double  ScreenScalerY = 0.0;
    int CameraWidthChanger =0;
    int CameraHeightChanger=0;
    static int aNumber = (int) (Math.random() * 50 + (int) (Math.random() * 10));
    static int bNumber = (int) (Math.random() * 50 + 50); //maybe they should add with each other or something like that
    static int cNumber = (int) (Math.random() * 50 + 100);//http://www.andengine.org/forums/gles2/random-time-before-sprite-appearance-t9936.html another solution
    static int dNumber = (int) (Math.random() * 50 + 100);
    // ===========================================================
    // Fields
    // ===========================================================
 
    private Camera mCamera;
    private Scene mMainScene;
    private BitmapTextureAtlas myBackgroundTextureAtlas;
    private IBitmapTextureAtlasSource myIBackgroundTextureAtlas;
	private TextureRegion myBackgroundTextureRegion;	
	private TextureRegion myBackground1TextureRegion;
	private BitmapTextureAtlas myBackground1TextureAtlas;
	private TiledTextureRegion mPlayerTiledTextureRegion;
	private TiledTextureRegion mPlayerTiled2TextureRegion;
    private BitmapTextureAtlas mBitmapTextureAtlas;
    private TiledTextureRegion mPlayerTextureRegion;
    private TiledTextureRegion mEnemyTextureRegion;
    private BitmapTextureAtlas mAutoParallaxBackgroundTexture;
    private TextureRegion mParallaxLayerBack;
    private TextureRegion mParallaxLayerMid;
    private TextureRegion mParallaxLayerFront;
    private TextureRegion mParallaxDinamicBackground;
    private TextureRegion mParallaxDinamic1Background;
    private TextureRegion mParallaxDinamic2Background;
    private TextureRegion mParallaxStaticBackground;
    private TextureRegion mParallaxStatic1Background;
    //private Camera mCamera;
	private AccelerometerHelper mAccelerometerHelper;
	//private Scene mMainScene;

	private ArrayList<Platform> mPlatforms = new ArrayList<Platform>();

	private BitmapTextureAtlas mPlayerBitmapTextureAtlas;
	//private TextureRegion mPlayerTextureRegion;

	private BitmapTextureAtlas mPlatformBitmapTextureAtlas;
	private TiledTextureRegion mPlatformTextureRegion;
    // ===========================================================
    // Constructors
    // ===========================================================
 
    // ===========================================================
    // Getter & Setter
    // ===========================================================
 
    // ===========================================================
    // Methods for/from SuperClass/Interfaces
    // ===========================================================
     
    @Override
    public EngineOptions onCreateEngineOptions() {
    	mAccelerometerHelper = new AccelerometerHelper(this);
    	final Display display = getWindowManager().getDefaultDisplay();
    	int cameraWidth = display.getWidth();
        int cameraHeight = display.getHeight();
        CAMERA_WIDTH=cameraWidth;
        CAMERA_HEIGHT=cameraHeight;
        //ScreenScalerX=CAMERA_WIDTH;
        //ScreenScalerY=CAMERA_HEIGHT;
        this.mCamera = new Camera(0, 0, cameraWidth, cameraHeight);
        
        if(CAMERA_WIDTH>960 && CAMERA_WIDTH<=1280){ScreenScalerX=10.0;}
        if(CAMERA_WIDTH>800 && CAMERA_WIDTH<=960){ScreenScalerX=7.5;}
        if(CAMERA_WIDTH>480 && CAMERA_WIDTH<=800){ScreenScalerX=6.25;}
        if(CAMERA_WIDTH>320 && CAMERA_WIDTH<=480){ScreenScalerX=3.75;}
        if(CAMERA_WIDTH<=320){ScreenScalerX=2.5;}
        
        if(CAMERA_HEIGHT>540 && CAMERA_HEIGHT<=800){ScreenScalerY=6.25;}
        if(CAMERA_HEIGHT>480 && CAMERA_HEIGHT<=540){ScreenScalerY=4.2;}
        if(CAMERA_HEIGHT>320 && CAMERA_HEIGHT<=480){ScreenScalerY=3.75;}
        if(CAMERA_HEIGHT>240 && CAMERA_HEIGHT<=320){ScreenScalerY=2.5;}
        if(CAMERA_HEIGHT<=240){ScreenScalerY=1.875;}
        
        return new EngineOptions(true, ScreenOrientation.LANDSCAPE_FIXED, new RatioResolutionPolicy(CAMERA_WIDTH, CAMERA_HEIGHT), this.mCamera);
       // this.mCamera = new Camera(0, 0, CAMERA_WIDTH, CAMERA_HEIGHT);
       // return new Engine(new EngineOptions(true, ScreenOrientation.LANDSCAPE, new RatioResolutionPolicy(CAMERA_WIDTH, CAMERA_HEIGHT), this.mCamera));
    }
    
    //from http://andengine.wikidot.com/detect-screen-resolution ||| Detect Screen Resolution
    public Engine onLoadEngine() {
        final Display display = getWindowManager().getDefaultDisplay();
        int cameraWidth = display.getWidth();
        int cameraHeight = display.getHeight();
     
        String deb = String.format("Screen: %d / %d",cameraWidth,cameraHeight);
        Log.d("Debug:", deb);
     
        this.mCamera = new Camera(0, 0, cameraWidth,cameraHeight);
        return new Engine(new EngineOptions(true, ScreenOrientation.LANDSCAPE_FIXED, 
            new RatioResolutionPolicy(cameraWidth, cameraHeight), this.mCamera));
    }
   
    @Override
    public void onCreateResources() { 
    	BitmapTextureAtlasTextureRegionFactory.setAssetBasePath("gfx/");
    	myBackgroundTextureAtlas  = new BitmapTextureAtlas(this.getTextureManager(), CAMERA_WIDTH, CAMERA_HEIGHT);
    	myBackgroundTextureRegion = BitmapTextureAtlasTextureRegionFactory.createFromAsset(this.myBackgroundTextureAtlas, this, "MainObject.png",128,128); 
    	this.mPlayerTiledTextureRegion = BitmapTextureAtlasTextureRegionFactory.createTiledFromAsset(this.myBackgroundTextureAtlas, this, "MainObject.png", 128, 128, 1,1 );

    	myBackground1TextureRegion = BitmapTextureAtlasTextureRegionFactory.createFromAsset(this.myBackgroundTextureAtlas, this, "meteorite.png",0,0); 
    	this.mPlayerTiled2TextureRegion = BitmapTextureAtlasTextureRegionFactory.createTiledFromAsset(this.myBackgroundTextureAtlas, this, "meteorite.png", 0, 0, 1,1 );

        this.mBitmapTextureAtlas = new BitmapTextureAtlas(this.getTextureManager(),256, 128, TextureOptions.BILINEAR_PREMULTIPLYALPHA);
        this.mPlayerTextureRegion = BitmapTextureAtlasTextureRegionFactory.createTiledFromAsset(this.mBitmapTextureAtlas, this, "player.png", 0, 0, 3, 4);
        this.mEnemyTextureRegion = BitmapTextureAtlasTextureRegionFactory.createTiledFromAsset(this.mBitmapTextureAtlas, this, "enemy.png", 73, 0, 3, 4);
        
        this.mAutoParallaxBackgroundTexture = new BitmapTextureAtlas(this.getTextureManager(),1820,1024 , TextureOptions.BILINEAR_PREMULTIPLYALPHA);

        
        this.mParallaxStaticBackground = BitmapTextureAtlasTextureRegionFactory.createFromAsset(this.mAutoParallaxBackgroundTexture,this, "1280x720outer_space_trip_08_by_brujo.png",480,0);
        this.mParallaxDinamic2Background = BitmapTextureAtlasTextureRegionFactory.createFromAsset(this.mAutoParallaxBackgroundTexture,this, "480x720White.png",0,0);
        this.mParallaxDinamic1Background = BitmapTextureAtlasTextureRegionFactory.createFromAsset(this.mAutoParallaxBackgroundTexture,this, "480x720White.png",0,0);
      
        this.mParallaxDinamicBackground = BitmapTextureAtlasTextureRegionFactory.createFromAsset(this.mAutoParallaxBackgroundTexture,this, "480x720White.png",0,0);
        /* Texture for Player */
		this.mPlayerBitmapTextureAtlas = new BitmapTextureAtlas(this.getTextureManager(), 128, 128);
		this.mPlayerTextureRegion = BitmapTextureAtlasTextureRegionFactory.createTiledFromAsset(this.mPlayerBitmapTextureAtlas, this, "MainObject.png", 0, 0, 1, 1);
		this.mPlayerBitmapTextureAtlas.load();

		/* Texture for platform */
		this.mPlatformBitmapTextureAtlas = new BitmapTextureAtlas(this.getTextureManager(), 128, 128);
		this.mPlatformTextureRegion = BitmapTextureAtlasTextureRegionFactory.createTiledFromAsset(this.mPlatformBitmapTextureAtlas, this, "meteorite.png", 0, 0,1,1);
		this.mPlatformBitmapTextureAtlas.load();
        mBitmapTextureAtlas.load();
        mAutoParallaxBackgroundTexture.load();

    	myBackgroundTextureAtlas.load();

    	}
 

    @Override
    protected Scene onCreateScene() {
        this.mEngine.registerUpdateHandler(new FPSLogger()); // logs the frame rate
        this.mMainScene = new Scene();

        this.mEngine.getTextureManager().loadTexture(this.myBackgroundTextureAtlas);

       

       
        final int centerX = (CAMERA_WIDTH - myBackgroundTextureAtlas.getWidth()) / 2;
        final int centerY = (CAMERA_HEIGHT - myBackgroundTextureAtlas.getHeight()) / 2;
   
        //final Player oPlayer = new Player(CAMERA_WIDTH/2-128/2, CAMERA_HEIGHT-128, this.mPlayerTiledTextureRegion, this.getVertexBufferObjectManager());
        //this.mMainScene.attachChild(oPlayer);
        /* Create the sprite and add it to the scene. */
		final Player oPlayer = new Player(CAMERA_WIDTH, CAMERA_HEIGHT-128, this.mPlayerTextureRegion, this.getVertexBufferObjectManager());
		this.mMainScene.attachChild(oPlayer);

		mPlatforms.add(new Platform(100+aNumber, +aNumber, this.mPlatformTextureRegion, this.getVertexBufferObjectManager()));
		mPlatforms.add(new Platform(300+bNumber, +bNumber, this.mPlatformTextureRegion, this.getVertexBufferObjectManager()));
		mPlatforms.add(new Platform(500+cNumber, +cNumber, this.mPlatformTextureRegion, this.getVertexBufferObjectManager()));
		oPlayer.setmPlatforms(mPlatforms); // Adds platforms, so we can work with them (Player.java)

		for (Platform Platform : mPlatforms) {
			this.mMainScene.attachChild(Platform);
		}
        
       // final Player1 oPlayer1 = new Player1(centerX+128 , centerY+256, this.mPlayerTiled2TextureRegion, this.getVertexBufferObjectManager());
       // this.mMainScene.attachChild(oPlayer1);

        
       final AutoParallaxBackground autoParallaxBackground = new AutoParallaxBackground(0, 0, 0, 5);
       
       autoParallaxBackground.attachParallaxEntity(new ParallaxEntity(0.0f, new Sprite(CAMERA_WIDTH - (CAMERA_WIDTH-1), CAMERA_HEIGHT - (CAMERA_HEIGHT-1), this.mParallaxStaticBackground, this.getVertexBufferObjectManager())));
      autoParallaxBackground.attachParallaxEntity(new ParallaxEntity(25.0f, new Sprite(480, centerY, this.mParallaxDinamic1Background, this.getVertexBufferObjectManager())));
      autoParallaxBackground.attachParallaxEntity(new ParallaxEntity(25.0f, new Sprite(0, centerY, this.mParallaxDinamicBackground, this.getVertexBufferObjectManager())));
      autoParallaxBackground.attachParallaxEntity(new ParallaxEntity(25.0f, new Sprite(960, centerY, this.mParallaxDinamic2Background, this.getVertexBufferObjectManager())));

       this.mMainScene.setBackground(autoParallaxBackground);      

      
        return this.mMainScene;
    }
   
}

