package com.example.spacechase;

import org.andengine.opengl.texture.region.ITiledTextureRegion;
import org.andengine.opengl.texture.region.TextureRegion;
import org.andengine.opengl.vbo.VertexBufferObjectManager;

public class Platform extends GameObject {

	// ===========================================================
	// Constants
	// ===========================================================

	// ===========================================================
	// Fields
	// ===========================================================

	// ===========================================================
	// Constructors
	// ===========================================================

	public Platform(int pX, int pY,final ITiledTextureRegion pTiledTextureRegion, VertexBufferObjectManager pVertexBufferObjectManager) {
		super(pX, pY, pTiledTextureRegion, pVertexBufferObjectManager);
	}

	// ===========================================================
	// Getter & Setter
	// ===========================================================

	// ===========================================================
	// Methods for/from SuperClass/Interfaces
	// ===========================================================

	@Override
	public void move() {
		// TODO Auto-generated method stub
		this.mPhysicsHandler.setVelocityY(100);
		OutOfScreenY();
	}

	// ===========================================================
	// Methods
	// ===========================================================
	private void OutOfScreenY() {
		if (mY > MainActivity.CAMERA_WIDTH) { // OutOfScreenX (right)
			mY = 0;
		} else if (mY < 0) { // OutOfScreenX (left)
			mY = MainActivity.CAMERA_WIDTH;
		}
	}
}
