//from http://perle-development.com/tutorials/andengine-tutorial-03-player-movement-01/ ||| implements movemtn
//START 9
package com.example.spacechase;

import java.util.ArrayList;

import org.andengine.opengl.texture.region.ITiledTextureRegion;
import org.andengine.opengl.texture.region.TiledTextureRegion;
import org.andengine.opengl.vbo.VertexBufferObjectManager;

import android.util.Log;

import com.example.spacechase.MainActivity;

public class Player extends GameObject {

	// ===========================================================
	// Constants
	// ===========================================================

	final int DEFAULT_VELOCITY = 200;

	// ===========================================================
	// Fields
	// ===========================================================

	boolean jumping = false;
	private ArrayList<Platform> mPlatforms;

	// ===========================================================
	// Constructors
	// ===========================================================

	  public Player(final float pX, final float pY, final ITiledTextureRegion pTiledTextureRegion, final VertexBufferObjectManager pVertexBufferObjectManager) {
	        super(pX, pY, pTiledTextureRegion, pVertexBufferObjectManager);
	}

	// ===========================================================
	// Getter & Setter
	// ===========================================================

	public ArrayList<Platform> getmPlatforms() {
		return mPlatforms;
	}

	public void setmPlatforms(ArrayList<Platform> mPlatforms) {
		this.mPlatforms = mPlatforms;
	}

	// ===========================================================
	// Methods for/from SuperClass/Interfaces
	// ===========================================================

	@Override
	public void move() {

		this.mPhysicsHandler.setVelocityX(-AccelerometerHelper.TILT * DEFAULT_VELOCITY);
		setRotation(-AccelerometerHelper.TILT * 7);
		OutOfScreenX();

	//	Jumping();

		for (Platform Platform : getmPlatforms()) {
			if (this.collidesWith(Platform)) {
				Log.v("objects.Player", "just collided with platform ;)");
			}
		}

	}

	// ===========================================================
	// Methods
	// ===========================================================

	private void Jumping() {
		if (jumping) {
			Jump();
		} else {
			Fall();
		}
	}

	private void Jump() {
		if (mY <= MainActivity.CAMERA_HEIGHT / 2) { // mY <= 400
			jumping = false;
		} else {
			this.mPhysicsHandler.setVelocityY(-DEFAULT_VELOCITY);
		}
	}

	private void Fall() {
		if (mY >= MainActivity.CAMERA_HEIGHT) { // mY >= 800
			jumping = true;
		} else {
			this.mPhysicsHandler.setVelocityY(DEFAULT_VELOCITY);
		}
	}

	private void OutOfScreenX() {
		if (mX > MainActivity.CAMERA_WIDTH) { // OutOfScreenX (right)
			mX = 0;
		} else if (mX < 0) { // OutOfScreenX (left)
			mX = MainActivity.CAMERA_WIDTH;
		}
	}
}